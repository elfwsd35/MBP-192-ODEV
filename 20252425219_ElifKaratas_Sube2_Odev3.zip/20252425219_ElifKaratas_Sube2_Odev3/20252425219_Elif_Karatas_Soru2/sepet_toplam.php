<?php
$urun_adi      = trim($_POST['urun_adi'] ?? '');
$urun_fiyati   = $_POST['urun_fiyati'] ?? '';
$adet          = $_POST['adet'] ?? '';
$kdv           = $_POST['kdv'] ?? '';
$indirim_kodu  = strtoupper(trim($_POST['indirim_kodu'] ?? ''));

$hatalar = [];
if (empty($urun_adi))    $hatalar[] = "Ürün adı boş olamaz.";
if ($urun_fiyati === '') $hatalar[] = "Ürün fiyatı boş olamaz.";
if ($adet === '')        $hatalar[] = "Adet boş olamaz.";
if ($kdv === '')         $hatalar[] = "KDV oranı boş olamaz.";

$urun_fiyati = (float) $urun_fiyati;
$adet        = (int)   $adet;
$kdv         = (int)   $kdv;

if ($urun_fiyati <= 0) $hatalar[] = "Ürün fiyatı 0'dan büyük olmalıdır.";
if ($adet <= 0)        $hatalar[] = "Adet en az 1 olmalıdır.";
if ($kdv < 20)         $hatalar[] = "KDV oranı en az %20 olmalıdır.";

$indirim_yuzdesi = 0;
if (!empty($indirim_kodu)) {
    if ($indirim_kodu === 'IND20')      $indirim_yuzdesi = 20;
    elseif ($indirim_kodu === 'IND50')  $indirim_yuzdesi = 50;
    else $hatalar[] = "Geçersiz indirim kodu. Sadece IND20 veya IND50 kullanılabilir.";
}

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Sepet Sonucu</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-color: #f0f2f5;
            margin: 0;
        }
        .kutu {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            width: 360px;
        }
        h2 { text-align: center; color: #333; margin-bottom: 24px; }
        .hata { color: red; background: #fff0f0; padding: 10px; border-radius: 6px; margin-bottom: 10px; }
        .satir { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #eee; }
        .satir:last-child { border-bottom: none; }
        .baslik { font-weight: bold; color: #555; }
        .deger  { color: #333; }
        .toplam { font-size: 18px; font-weight: bold; color: #2196F3; margin-top: 10px; }
        .indirim-bilgi { color: #e91e63; font-size: 13px; margin-top: 4px; }
        a {
            display: inline-block;
            margin-top: 20px;
            color: #2196F3;
            text-decoration: none;
        }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>
<div class="kutu">
    <h2>🛒 Sepet Sonucu</h2>

    <?php if (!empty($hatalar)): ?>
        <?php foreach ($hatalar as $hata): ?>
            <div class="hata">⚠️ <?php echo htmlspecialchars($hata); ?></div>
        <?php endforeach; ?>
        <a href="index.html">← Geri Dön</a>

    <?php else:
        $ara_toplam    = $urun_fiyati * $adet;
        $kdv_tutari    = $ara_toplam * ($kdv / 100);
        $indirim_tutari = $ara_toplam * ($indirim_yuzdesi / 100);
        $genel_toplam  = $ara_toplam + $kdv_tutari - $indirim_tutari;
    ?>

        <p style="font-size:16px;font-weight:bold;color:#333;margin-bottom:16px;">
            <?php echo htmlspecialchars($urun_adi); ?> için toplam tutar:
            <span style="color:#2196F3"><?php echo number_format($genel_toplam, 2); ?> TL</span>
        </p>

        <div class="satir">
            <span class="baslik">Birim Fiyat</span>
            <span class="deger"><?php echo number_format($urun_fiyati, 2); ?> TL</span>
        </div>
        <div class="satir">
            <span class="baslik">Adet</span>
            <span class="deger"><?php echo $adet; ?></span>
        </div>
        <div class="satir">
            <span class="baslik">Ara Toplam</span>
            <span class="deger"><?php echo number_format($ara_toplam, 2); ?> TL</span>
        </div>
        <div class="satir">
            <span class="baslik">KDV Tutarı (%<?php echo $kdv; ?>)</span>
            <span class="deger"><?php echo number_format($kdv_tutari, 2); ?> TL</span>
        </div>

        <?php if ($indirim_yuzdesi > 0): ?>
        <div class="satir">
            <span class="baslik">İndirim</span>
            <span class="deger" style="color:#e91e63">
                "<?php echo htmlspecialchars($indirim_kodu); ?>" uygulanmıştır,
                İndirim Tutarı: <?php echo number_format($indirim_tutari, 2); ?> TL
            </span>
        </div>
        <?php endif; ?>

        <div class="satir toplam">
            <span>Genel Toplam</span>
            <span><?php echo number_format($genel_toplam, 2); ?> TL</span>
        </div>

        <a href="index.html">← Yeni Hesaplama</a>
    <?php endif; ?>
</div>
</body>
</html>