<?php

$kullanici_adi = $_POST['kullanici_adi'] ?? '';
$sifre         = $_POST['sifre'] ?? '';

$mesaj = '';
$mesaj_renk = '';

// Boş alan kontrolü
if (empty($kullanici_adi) || empty($sifre)) {
    $mesaj = "Lütfen tüm alanları doldurun";
    $mesaj_renk = "red";
}
// Güvenlik: sadece string olduğunu doğrula
elseif (!is_string($kullanici_adi) || !is_string($sifre)) {
    $mesaj = "Geçersiz veri";
    $mesaj_renk = "red";
}
// Kullanıcı adı ve şifre kontrolü
elseif ($kullanici_adi === 'admin' && $sifre === '1234') {
    $mesaj = "Giriş başarılı, hoş geldiniz admin";
    $mesaj_renk = "green";
}
else {
    $mesaj = "Kullanıcı adı ya da şifre hatalı";
    $mesaj_renk = "red";
}

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Giriş Sonucu</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #0f1117;
            margin: 0;
        }
        .sonuc-kutu {
            background: #1e2130;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.5);
            text-align: center;
            width: 320px;
            border: 1px solid #2e3250;
        }
        .mesaj {
            font-size: 18px;
            font-weight: bold;
            color: <?php echo ($mesaj_renk === 'green') ? '#4ade80' : '#f87171'; ?>;
        }
        a {
            display: inline-block;
            margin-top: 20px;
            color: #4f8ef7;
            text-decoration: none;
        }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <div class="sonuc-kutu">
        <p class="mesaj"><?php echo htmlspecialchars($mesaj); ?></p>
        <a href="index.html">← Geri Dön</a>
    </div>
</body>
</html>