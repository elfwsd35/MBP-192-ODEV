<?php
$ilan = $_GET["ilan"];
if($_POST){
    $isim = $_POST["isim"];
    echo "<h2>Başvuru Alındı: $isim</h2>";
}
?>
<!DOCTYPE html>>
<html>
    <head>
        <title>Başvur</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <h2><?php echo $ilan; ?> için başvuru</h2>
        <form method="post">
            <input type="text" name="isim" placeholder="Adınız" required>
            <br><br>
            <textarea name="cv" placeholder="Kısa CV"></textarea>
            <br><br>
            <button type="submit">Gönder</button>
        </form>
    </body>
</html>