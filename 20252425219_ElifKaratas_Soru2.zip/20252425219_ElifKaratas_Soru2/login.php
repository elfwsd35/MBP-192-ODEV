<?php
session_start();
if($_POST){
    $_SESSION["kullanici"] = $_POST["isim"];
    header("Location: index.php");
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Giriş Yap</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <h2>Giriş Yap</h2>
        <form method="post">
            <input type="text" name="isim" placeholder="Adınız" required>
            <br><br>
            <button type ="submit">Giriş Yap</button>
        </form>
    </body>

</html>