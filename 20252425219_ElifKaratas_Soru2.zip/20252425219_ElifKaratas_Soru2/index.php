<?php
session_start();

$baslik = "Staj & İş Bul Platformu";
$aciklama = "Kariyerine yön ver ve staj/iş fırsatlarını keşfet!";
$kullanici = isset($_SESSION["kullanici"]) ? $_SESSION["kullanici"] : "Misafir";

$ilanlar = [
    ["isim" => "Frontend Developer Stajyeri",       "tur" => "Staj",         "sirket" => "ABC Yazılım",  "sehir" => "İzmir"],
    ["isim" => "Backend Developer",                  "tur" => "Tam Zamanlı",  "sirket" => "TechSoft",     "sehir" => "İstanbul"],
    ["isim" => "Mobil Uygulama Geliştirici",         "tur" => "Tam Zamanlı",  "sirket" => "Mobilix",      "sehir" => "Ankara"],
    ["isim" => "UI/UX Designer Stajyeri",            "tur" => "Staj",         "sirket" => "DesignerPro",  "sehir" => "İzmir"],
    ["isim" => "Veri Analisti",                      "tur" => "Tam Zamanlı",  "sirket" => "DataInsights", "sehir" => "İstanbul"],
    ["isim" => "Siber Güvenlik Uzmanı",              "tur" => "Tam Zamanlı",  "sirket" => "SecureTech",   "sehir" => "Ankara"],
    ["isim" => "Yazılım Test Mühendisi Stajyeri",    "tur" => "Staj",         "sirket" => "TestLab",      "sehir" => "İzmir"],
    ["isim" => "Bulut Bilişim Uzmanı",               "tur" => "Tam Zamanlı",  "sirket" => "CloudNet",     "sehir" => "İstanbul"],
    ["isim" => "Yapay Zeka Mühendisi",               "tur" => "Tam Zamanlı",  "sirket" => "AIGenius",     "sehir" => "Ankara"],
    ["isim" => "Sosyal Medya Yöneticisi Stajyeri",   "tur" => "Staj",         "sirket" => "SocialBuzz",   "sehir" => "İzmir"],
];

$filtre = isset($_GET["tur"]) ? $_GET["tur"] : "hepsi";
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $baslik; ?></title>
    <meta name="description" content="<?php echo $aciklama; ?>">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1><?php echo $baslik; ?></h1>
        <p><?php echo $aciklama; ?></p>
    </header>

    <div class="topbar">
        <span>👤 <?php echo $kullanici; ?></span>
        <a href="login.php">Giriş Yap</a>
    </div>

    <div class="filtre">
        <a href="index.php"><button>Hepsi</button></a>
        <a href="index.php?tur=Staj"><button>Staj</button></a>
        <a href="index.php?tur=Tam Zamanlı"><button>Tam Zamanlı İş</button></a>
    </div>

    <h2>Güncel İlanlar</h2>
    <div class="jobs">
        <?php foreach ($ilanlar as $ilan): ?>
            <?php if ($filtre != "hepsi" && $ilan["tur"] != $filtre) continue; ?>
            <div class="card">
                <h3><?php echo $ilan["isim"]; ?></h3>
                <p>🏢 <?php echo $ilan["sirket"]; ?></p>
                <p>📍 <?php echo $ilan["sehir"]; ?></p>
                <span class="etiket <?php echo $ilan["tur"] == 'Staj' ? 'staj' : 'is'; ?>">
                    <?php echo $ilan["tur"]; ?>
                </span>
                <br><br>
                <a href="basvur.php?ilan=<?php echo urlencode($ilan["isim"]); ?>">
                    <button>Başvur</button>
                </a>
            </div>
        <?php endforeach; ?>
    </div>

    <p>Toplam ilan: <?php echo count($ilanlar); ?></p>

    <h2>Kullanıcıya Sunulan Olanaklar</h2>
    <ul>
        <li>✔️ Kolay başvuru sistemi</li>
        <li>✔️ Farklı şehirlerde iş fırsatları</li>
        <li>✔️ Staj ve tam zamanlı iş seçenekleri</li>
        <li>✔️ Hızlı ve kullanıcı dostu arayüz</li>
    </ul>
</body>
</html>